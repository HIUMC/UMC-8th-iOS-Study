//
//  Practice6App.swift
//  Practice6
//
//  Created by 신민정 on 5/13/25.
//

import SwiftUI

@main
struct Practice6App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
