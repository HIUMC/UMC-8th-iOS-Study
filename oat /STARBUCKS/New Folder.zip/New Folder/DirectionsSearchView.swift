//
//  DirectionsSearchView.swift
//  STARBUCKS
//
//  Created by 신민정 on 5/19/25.
//
// 출발지 도착지 입력 UI + 경로 검색 버튼
// 

import Foundation
import CoreLocation
import SwiftUI

struct DirectionsSearchView: View {
    @State private var didTapCurrentLocation: Bool = false
    @State private var showRouteAlert = false
    @State private var alertMessage = ""
    @State private var lastLocation: CLLocation?
    @State private var searchText = ""
    @State private var arrivalText = ""
    @State private var departureText: String = ""
    @ObservedObject var viewModel: DirectionsSearchViewModel
    @ObservedObject var storeDataManager: StoreDataManager
    @StateObject private var destinationVM = DestinationSearchViewModel()
    @StateObject private var placeSearchVM = PlaceSearchViewModel()
    
    
    
    var body: some View {
        VStack(spacing: 16) {
            // 출발지 입력
            VStack(alignment: .leading, spacing: 4) {
                Text("출발")
                    .font(.mainTextSemibold16)
                HStack {
                    Button(action: {
                        didTapCurrentLocation = true
                        storeDataManager.requestLocation()
                        
                        
                    }) {
                        Text("현재위치")
                            .font(.caption)
                            .padding(8)
                            .background(.brown01)
                            .foregroundColor(.white)
                            .cornerRadius(6)
                    }
                    
                    TextField("출발지를 입력하세요", text: $searchText)
                        .textFieldStyle(.roundedBorder)
                    Button(action: {
                        placeSearchVM.search(keyword: searchText)
                    }) {
                        Image("magnifyingglass")
                    }
                }
            }
            .onReceive(storeDataManager.$currentAddress) { newAddress in
                searchText = newAddress
            }
            
            
            // 도착지
            VStack(alignment: .leading, spacing: 4) {
                Text("도착")
                    .font(.mainTextSemibold16)
                HStack {
                    TextField("매장명 또는 주소", text: $arrivalText)
                        .textFieldStyle(.roundedBorder)
                    Button(action: {
                        destinationVM.query = arrivalText
                        destinationVM.search(in: storeDataManager.stores)
                    }) {
                        Image("magnifyingglass")
                    }
                }
            }
            
            if !destinationVM.results.isEmpty {
                List(destinationVM.results) { store in
                    Button {
                        arrivalText = store.name
                        destinationVM.results = []
                    } label: {
                        VStack(alignment: .leading) {
                            Text(store.name)
                                .font(.headline)
                            Text(store.address)
                                .font(.subheadline)
                                .foregroundColor(.gray)
                        }
                        .padding(.vertical, 4)
                    }
                }
                .listStyle(.plain)
                .frame(height: 250)
            }
            
            // 경로 찾기 버튼
            Button("경로 찾기") {
                guard let start = storeDataManager.stores.first(where: { $0.name == searchText }) else {
                    alertMessage = "출발지가 등록된 매장이 아닙니다."
                    showRouteAlert = true
                    return
                }
                
                // 도착지 항목
                guard let end = storeDataManager.stores.first(where: { $0.name == arrivalText }) else {
                    alertMessage = "도착지가 등록된 매장이 아닙니다."
                    showRouteAlert = true
                    return
                }
                
                // 좌표로 변환-> 요청 보내기
                let startCoord = CLLocationCoordinate2D(latitude: start.latitude, longitude: start.longitude)
                let endCoord = CLLocationCoordinate2D(latitude: end.latitude, longitude: end.longitude)
                
                viewModel.searchRoute(from: startCoord, to: endCoord)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 10)
            .padding()
            .background(Color.green00)
            .foregroundColor(.white)
            .cornerRadius(8)
            
            Spacer()
            // 검색 결과 리스트
            if !placeSearchVM.results.isEmpty {
                List {
                    ForEach(placeSearchVM.results) { place in
                        Button {
                            // 장소 선택 로직
                        } label: {
                            VStack(alignment: .leading) {
                                Text(place.placeName)
                                Text(place.addressName)
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            }
                            .padding(.vertical, 4)
                        }
                    }
                }
                .listStyle(.plain)
                .frame(height: 250)
            }
        }
        .ignoresSafeArea(edges: .top)
        .padding()
        .alert(isPresented: $placeSearchVM.showAlert) {
            Alert(
                title: Text("알림"),
                message: Text(placeSearchVM.alertMessage),
                dismissButton: .default(Text("확인"))
            )
        }
        .onReceive(placeSearchVM.$selectedPlace) { place in
            if let place = place {
                searchText = place.placeName
                departureText = place.addressName
            }
        }
        //내 위치에 가장 가까운 매장 입력
        .onChange(of: storeDataManager.userLocation) { newLoc in
            guard didTapCurrentLocation, let loc = newLoc else { return }

            if let nearest = storeDataManager.stores.min(by: {
                let a = CLLocation(latitude: $0.latitude, longitude: $0.longitude)
                let b = CLLocation(latitude: $1.latitude, longitude: $1.longitude)
                let me = CLLocation(latitude: loc.coordinate.latitude,
                                    longitude: loc.coordinate.longitude)
                return me.distance(from: a) < me.distance(from: b)
            }) {
                searchText = nearest.name
            }

            didTapCurrentLocation = false
        }

    }
}
