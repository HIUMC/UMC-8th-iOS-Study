//
//  PlaceSearchViewModel.swift
//  STARBUCKS
//
//  Created by 신민정 on 5/19/25.
//
// 카카오 키워드 검색 결과 관리 
//출발지 키워드
import Foundation
import Moya
import CoreLocation

class PlaceSearchViewModel: ObservableObject {
    @Published var results: [Place] = []
    @Published var selectedPlace: Place?
    @Published var departureCoordinate: CLLocationCoordinate2D?
    @Published var alertMessage: String = ""
    @Published var showAlert: Bool = false


    private let provider = MoyaProvider<KakaoRouter>()

    func search(keyword: String) {
        provider.request(.keywordSearch(query: keyword)) { [weak self] result in
            switch result {
            case .success(let response):
                do {
                    let decoded = try JSONDecoder().decode(KakaoPlaceResponse.self, from: response.data)
                    DispatchQueue.main.async {
                        self?.results = decoded.documents
                    }
                } catch {
                    print("유저 데이터 디코더 오류", error)
                }

            case .failure(let error):
                print("error", error)
            }
        }
    }
}

