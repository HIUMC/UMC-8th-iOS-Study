//
//  OSRMProvider.swift
//  STARBUCKS
//
//  Created by 신민정 on 5/22/25.
//

import Foundation
import Moya

let provider = MoyaProvider<OSRMRouter>()

func testOSRMRequest() {
    provider.request(.route(start: "126.9784,37.5666", end: "127.0276,37.4979")) { result in
        switch result {
        case .success(let response):
            print("응답 성공: \(response)")
        case .failure(let error):
            print("오류 발생: \(error)")
        }
    }
}

