//
//  kakaoKeys.swift
//  STARBUCKS
//
//  Created by 신민정 on 5/17/25.
//

struct KakaoKeys {
    static let restAPIKey  = "93706baff0a136a7c1e71617cecc101e"
    static let redirectURI = "https://kakao93706baff0a136a7c1e71617cecc101e//oauth"
}

