//
//  KakaoPlaceResponse.swift
//  STARBUCKS
//
//  Created by 신민정 on 5/19/25.
//

import Foundation

struct KakaoPlaceResponse: Decodable {
    let documents: [PlaceDocument]
}

struct PlaceDocument: Decodable, Identifiable {
    var id: String { placeName + addressName }

    let placeName: String
    let addressName: String
    let x: String  // 경도
    let y: String  // 위도

    enum CodingKeys: String, CodingKey {
        case placeName = "place_name"
        case addressName = "address_name"
        case x, y
    }
}

