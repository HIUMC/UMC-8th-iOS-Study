//
//  DirectionsResponse.swift
//  STARBUCKS
//
//  Created by 신민정 on 5/19/25.
//

import Foundation
import CoreLocation

struct DirectionsResponse: Decodable {
    let routes: [Route]
}

struct Route: Decodable {
    let geometry: Geometry
}

struct Geometry: Decodable {
    let coordinates: [[Double]] // [longitude, latitude]

    var coordinatePoints: [CLLocationCoordinate2D] {
        return coordinates.map { CLLocationCoordinate2D(latitude: $0[1], longitude: $0[0]) }
    }
}



