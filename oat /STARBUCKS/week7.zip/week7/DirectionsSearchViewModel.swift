//
//  DirectionsSearchViewModel.swift
//  STARBUCKS
//
//  Created by 신민정 on 5/19/25.
//

import Foundation
import Moya
import CoreLocation

class DirectionsSearchViewModel: ObservableObject {
    @Published var isLoading = false
    @Published var routeCoordinates: [CLLocationCoordinate2D] = []

    private let provider = MoyaProvider<DirectionsRouter>()

    func searchRoute(from start: CLLocationCoordinate2D, to end: CLLocationCoordinate2D) {
        isLoading = true

        provider.request(.route(start: start, end: end)) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false

                switch result {
                case .success(let response):
                    do {
                        let decoded = try JSONDecoder().decode(OSRMResponse.self, from: response.data)
                        if let route = decoded.routes.first {
                            self?.routeCoordinates = route.geometry.coordinates.map {
                                CLLocationCoordinate2D(latitude: $0[1], longitude: $0[0])
                            }
                        }
                        else {
                            print("❌ 경로 없음")
                        }
                    } catch {
                        print("❌ 디코딩 오류:", error)
                    }

                case .failure(let error):
                    print("❌ 네트워크 오류:", error)
                }
                self?.isLoading = false
            }
        }
    }
}
