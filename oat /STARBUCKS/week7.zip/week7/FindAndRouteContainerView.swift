//
//  FindAndRouteContainerView.swift
//  STARBUCKS
//
//  Created by 신민정 on 5/20/25.
//

import Foundation
import SwiftUI

enum Segment: String, CaseIterable, Identifiable {
    case store = "매장 찾기"
    case route = "길찾기"
    var id: String { rawValue }
}

struct FindAndRouteContainerView: View {
    @StateObject private var storeDataManager = StoreDataManager()
    @StateObject private var directionsVM = DirectionsSearchViewModel()
    @State private var selected: Segment = .store

    var body: some View {
        VStack {
            // 1) 상단 세그먼트
            Picker("", selection: $selected) {
                ForEach(Segment.allCases) { seg in
                    Text(seg.rawValue).tag(seg)
                }
            }
            .pickerStyle(SegmentedPickerStyle())
            .padding()

            // 2) 선택된 화면
            switch selected {
            case .store:
                FindStoreView(storeDataManager: storeDataManager, directionsVM: directionsVM)
            case .route:
                DirectionsSearchView(
                    storeDataManager: storeDataManager,
                    routeVM: directionsVM
                )
            }
        }
    }
}

struct FindAndRouteContainerView_Previews: PreviewProvider {
    static var previews: some View {
        FindAndRouteContainerView()
    }
}
