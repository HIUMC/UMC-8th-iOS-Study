//
//  KakaoRouter.swift
//  STARBUCKS
//
//  Created by 신민정 on 5/19/25.
//

import Foundation
import Moya

enum KakaoRouter {
    case searchPlace(keyword: String)
}

extension KakaoRouter: TargetType {
    var baseURL: URL {
        return URL(string: "https://dapi.kakao.com")!
    }

    var path: String {
        switch self {
        case .searchPlace:
            return "/v2/local/search/keyword.json"
        }
    }

    var method: Moya.Method {
        return .get
    }
    
    var task: Task {
        switch self {
        case .searchPlace(let keyword):
            return .requestParameters(parameters: [
                "query": keyword,
                "radius": 5,
                "page": 1,
                "size": 15
            ], encoding: URLEncoding.queryString)
        }
    }
    
    var headers: [String : String]? {
           guard let apiKey = Bundle.main.object(forInfoDictionaryKey: "KAKAO_REST_API_KEY") as? String else {
               return nil
           }
           return ["Authorization": "KakaoAK \(apiKey)"]
       }
    
    var sampleData: Data {
        switch self {
        case .searchPlace:
            return """
            {
                "documents": [
                    {
                        "place_name": "중앙대학교 서울캠퍼스",
                        "address_name": "서울 동작구 흑석동 221"
                    },
                    {
                        "place_name": "중앙대병원",
                        "address_name": "서울 동작구 흑석로 102"
                    },
                    {
                        "place_name": "중앙대학교 미래관",
                        "address_name": "서울 동작구 흑석로 84"
                    }
                ]
            }
            """.data(using: .utf8)!
        }
    }


}


