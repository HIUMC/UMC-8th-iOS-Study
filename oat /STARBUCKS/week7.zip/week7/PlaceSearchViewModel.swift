//
//  PlaceSearchViewModel.swift
//  STARBUCKS
//
//  Created by 신민정 on 5/19/25.
//

import Foundation
import Moya

class PlaceSearchViewModel: ObservableObject {
    @Published var results: [PlaceDocument] = []
    @Published var showAlert = false
    @Published var alertMessage = ""

    private let provider = MoyaProvider<KakaoRouter>()
    
    func search(keyword: String) {
            provider.request(.searchPlace(keyword: keyword)) { [weak self] result in
                switch result {
                case .success(let response):
                    do {
                        let decoded = try JSONDecoder().decode(KakaoPlaceResponse.self, from: response.data)
                        if decoded.documents.isEmpty {
                            self?.alertMessage = "검색 결과가 존재하지 않습니다."
                            self?.showAlert = true
                        } else {
                            self?.results = decoded.documents
                        }
                    } catch {
                        self?.alertMessage = "데이터 해석 실패"
                        self?.showAlert = true
                    }
                case .failure:
                    self?.alertMessage = "네트워크 오류 발생"
                    self?.showAlert = true
                }
            }
        }
}
