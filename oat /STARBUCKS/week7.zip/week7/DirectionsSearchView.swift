//
//  DirectionsSearchView.swift
//  STARBUCKS
//
//  Created by 신민정 on 5/19/25.
//

import Foundation
import CoreLocation
import SwiftUI

struct DirectionsSearchView: View {
    @State private var showRouteAlert = false
    @State private var alertMessage = ""
    @StateObject private var placeSearchVM = PlaceSearchViewModel()
    @State private var searchText = ""
    @State private var arrivalText = ""
    @ObservedObject var storeDataManager: StoreDataManager
    @ObservedObject var routeVM: DirectionsSearchViewModel
    @StateObject private var destinationVM = DestinationSearchViewModel()



    var body: some View {
        VStack(spacing: 16) {
            // 출발지 입력
            VStack(alignment: .leading, spacing: 4) {
                Text("출발")
                    .font(.mainTextSemibold16)
                HStack {
                    Button(action: {
                        storeDataManager.requestLocation()
                        
                        
                    }) {
                        Text("현재위치")
                            .font(.caption)
                            .padding(8)
                            .background(Color.orange)
                            .foregroundColor(.white)
                            .cornerRadius(6)
                    }

                    TextField("출발지를 입력하세요", text: $searchText)
                        .textFieldStyle(.roundedBorder)
                    Button(action: {
                        placeSearchVM.search(keyword: searchText)
                    }) {
                        Image(systemName: "magnifyingglass")
                    }
                }
            }

            // 도착지 입력 (기능은 나중에 붙이자!)
            VStack(alignment: .leading, spacing: 4) {
                Text("도착")
                    .font(.mainTextSemibold16)
                HStack {
                    TextField("매장명 또는 주소", text: $arrivalText)
                        .textFieldStyle(.roundedBorder)
                    Button(action: {
                        destinationVM.query = arrivalText
                        destinationVM.search(in: storeDataManager.stores)
                    }) {
                        Image(systemName: "magnifyingglass")
                    }
                }
            }
            
            if !destinationVM.results.isEmpty {
                   List(destinationVM.results) { store in
                       Button {
                           arrivalText = store.name
                           destinationVM.results = []
                       } label: {
                           VStack(alignment: .leading) {
                               Text(store.name)
                                   .font(.headline)
                               Text(store.address)
                                   .font(.subheadline)
                                   .foregroundColor(.gray)
                           }
                           .padding(.vertical, 4)
                       }
                   }
                   .listStyle(.plain)
                   .frame(height: 250)
               }

            // 경로 찾기 버튼
            Button("경로 찾기") {
                guard let start = storeDataManager.stores.first(where: { $0.name == searchText }) else {
                    alertMessage = "출발지가 등록된 매장이 아닙니다."
                    showRouteAlert = true
                    return
                }
                
                // 2. 도착지 검색된 항목 찾기
                guard let end = storeDataManager.stores.first(where: { $0.name == arrivalText }) else {
                    alertMessage = "도착지가 등록된 매장이 아닙니다."
                    showRouteAlert = true
                    return
                }
                
                // 3. 좌표로 변환 후 요청 보내기
                let startCoord = CLLocationCoordinate2D(latitude: start.latitude, longitude: start.longitude)
                let endCoord = CLLocationCoordinate2D(latitude: end.latitude, longitude: end.longitude)
                
                routeVM.searchRoute(from: startCoord, to: endCoord)
            }
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color.green00)
            .foregroundColor(.white)
            .cornerRadius(8)

            // 검색 결과 리스트
            if !placeSearchVM.results.isEmpty {
                List(placeSearchVM.results) { place in
                    Button {
                        searchText = place.placeName
                        placeSearchVM.results = []
                    } label: {
                        VStack(alignment: .leading) {
                            Text(place.placeName)
                                .font(.headline)
                            Text(place.addressName)
                                .font(.subheadline)
                                .foregroundColor(.gray)
                        }
                        .padding(.vertical, 4)
                    }
                }
                .listStyle(.plain)
            }
        }
        .padding()
        .alert(isPresented: $placeSearchVM.showAlert) {
            Alert(
                title: Text("알림"),
                message: Text(placeSearchVM.alertMessage),
                dismissButton: .default(Text("확인"))
            )
        }
        .onChange(of: storeDataManager.userLocation) { newLoc in
            guard let loc = newLoc else { return }
            if let nearest = storeDataManager.stores.min(by: {
                let a = CLLocation(latitude: $0.latitude, longitude: $0.longitude)
                let b = CLLocation(latitude: $1.latitude, longitude: $1.longitude)
                let me = CLLocation(latitude: loc.coordinate.latitude,
                                    longitude: loc.coordinate.longitude)
                return me.distance(from: a) < me.distance(from: b)
            }) {
                searchText = nearest.name
            }
        }
    }
}
