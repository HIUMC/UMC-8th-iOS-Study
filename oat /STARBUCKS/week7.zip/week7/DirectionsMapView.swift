//
//  DirectionsMapView.swift
//  STARBUCKS
//
//  Created by 신민정 on 5/20/25.
//

import SwiftUI
import MapKit

struct DirectionsMapView: View {
    @ObservedObject var viewModel: DirectionsSearchViewModel

    var start: CLLocationCoordinate2D
    var end: CLLocationCoordinate2D

    @State private var region: MKCoordinateRegion

    init(viewModel: DirectionsSearchViewModel, start: CLLocationCoordinate2D, end: CLLocationCoordinate2D) {
        self.viewModel = viewModel
        self.start = start
        self.end = end

        // 초기 지도 중심: 출발지 기준
        _region = State(initialValue: MKCoordinateRegion(
            center: start,
            span: MKCoordinateSpan(latitudeDelta: 0.03, longitudeDelta: 0.03)
        ))
    }
    
    struct LocationPoint: Identifiable {
        let id = UUID()
        let coordinate: CLLocationCoordinate2D
    }

    var body: some View {
        ZStack {
            Map(coordinateRegion: $region, annotationItems: [start, end].map { LocationPoint(coordinate: $0) }) { item in
                MapAnnotation(coordinate: item.coordinate) {
                    Image(systemName: item.coordinate.latitude == start.latitude ? "circle.fill" : "flag.fill")
                        .foregroundColor(item.coordinate.latitude == start.latitude ? .blue : .red)
                        .font(.title)
                }
            }
            .overlay(
                RoutePolyline(coordinates: viewModel.routeCoordinates)
            )
            
            if viewModel.isLoading {
                ZStack {
                    Color.black.opacity(0.3).edgesIgnoringSafeArea(.all)
                    ProgressView("경로를 검색 중")
                        .padding()
                        .background(.ultraThinMaterial)
                        .cornerRadius(12)
                        .font(.title3)
                }
            }
        }
        .onAppear {
            viewModel.searchRoute(from: start, to: end)
        }
    }
}


