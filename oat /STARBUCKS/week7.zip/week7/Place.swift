//
//  Place.swift
//  STARBUCKS
//
//  Created by 신민정 on 5/19/25.

import Foundation

struct Place: Identifiable, Decodable {
    let id = UUID()
    let placeName: String
    let addressName: String
}
